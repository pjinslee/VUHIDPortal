-- 
-- Database: `vuhid-portal`
-- 
DROP DATABASE IF EXISTS `vuhid-portal`;
CREATE DATABASE IF NOT EXISTS `vuhid-portal` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
